package com.AppRH.AppRH;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RhappApplicationTests {

	@Test
	void contextLoads() {
	}

}
