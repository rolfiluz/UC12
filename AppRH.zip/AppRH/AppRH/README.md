# App RH *versão 0.01* para estudos na UC 12

## Java com SPRING-BOOT

### Instruções de instalação e uso:

1º No MySQL criar um banco com o nome **AppRH**;

2º No Eclipse, ir em *file*, *importar*, escolher opção *Maven*, *Existing Maven Projects*, *next*, selecione a pasta do seu projeto em *browser*, marque a opção em Projects *seuProjeto.jar* e *finish*; 

3º Para executar o projeto no Eclipse, escolher *Run RhappApplication* e executar como uma aplicação Java;

4º Acessar em: http://localhost:8080/


Obs.: O projeto *não funciona* se não existir um banco (vazio) chamado AppRH no MySQL.

Obs.: O App ainda está com bugs...rs
